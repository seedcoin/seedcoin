Seedcoin: Start sowing, start growing.
 
Scrypt Proof of Work
1.3 Billion total coins
Blocks of 800 Coins, halving every 1.6 Million Blocks
2.5 Minute Block Targeting
Diff adjustment every 1300 Blocks
Default RPCPort=8722
Default P2PPort=8723


